// src/global.d.ts
interface Window {
    Buffer: typeof Buffer;
  }
  